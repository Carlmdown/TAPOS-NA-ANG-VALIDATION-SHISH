import os
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PyQt6.QtWidgets import QApplication, QLabel

from database import Database
from models import PriceExtra, Service
from services.appointment_manager import AppointmentManager
from services.client_manager import ClientManager
from services.loyalty_manager import LoyaltyManager
from services.notification_service import NotificationService
from services.pricing_calculator import PricingCalculator
from services.service_manager import ServiceManager
from ui.customer_screens.appointment_screen import CustomerAppointmentScreen


class CustomerAppointmentFlowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.application = QApplication.instance() or QApplication([])

    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory(
            prefix="customer_appointment_flow_"
        )
        self.database = Database(
            Path(self.temporary_directory.name) / "appointment.sqlite"
        )
        self.database.initialize_schema()
        self.service = self.database.add_service(
            Service(
                "Flow Test Service",
                250,
                length_prices={"Extra Long": 25},
                design_add_on_prices={"Intricate": 75},
            )
        )
        self.database.add_price_extra(PriceExtra("Flow Test Chrome", 20))
        calculator = PricingCalculator()
        appointment_manager = AppointmentManager(
            self.database,
            calculator,
            NotificationService(),
            LoyaltyManager(self.database),
        )
        self.screen = CustomerAppointmentScreen(
            ClientManager(self.database),
            ServiceManager(self.database),
            appointment_manager,
            calculator,
        )

    def tearDown(self) -> None:
        self.screen.close()
        self.database.close()
        self.temporary_directory.cleanup()

    def test_booking_summary_shows_base_and_selected_option_prices(self) -> None:
        self.screen._select_service(self.service)
        self.screen._select_length("Extra Long")
        self.screen._toggle_add_on("Intricate", True)
        self.screen._toggle_extra("Flow Test Chrome", True)

        self.assertEqual(self.screen._summary_service_price.text(), "₱250.00")
        prices = [
            self.screen._summary_line_items_layout.itemAt(index)
            .widget()
            .findChild(QLabel, "summaryLineItemPrice")
            .text()
            for index in range(
                self.screen._summary_line_items_layout.count()
            )
        ]
        self.assertEqual(prices, ["+₱25.00", "+₱75.00", "+₱20.00"])
        self.assertEqual(self.screen._summary_total_value.text(), "₱370.00")

    def test_customer_can_continue_and_cancel_before_saving(self) -> None:
        self.screen._select_service(self.service)
        self.screen._select_length("Extra Long")

        self.assertFalse(self.screen._footer.isHidden())
        self.assertEqual(
            self.screen._footer_button.text(), "Continue to Date & Time"
        )
        self.assertTrue(self.screen._footer_button.isEnabled())
        with (
            patch.object(self.screen, "_set_calendar_minimum"),
            patch.object(self.screen, "_refresh_slots"),
        ):
            self.screen._footer_button.click()
        self.assertEqual(self.screen._step_stack.currentIndex(), 1)

        self.screen._select_slot(datetime.now() + timedelta(days=2))
        self.screen._footer_button.click()
        self.assertEqual(self.screen._step_stack.currentIndex(), 2)
        self.assertEqual(self.screen._footer_button.text(), "Save Booking")
        self.assertFalse(self.screen._cancel_button.isHidden())
        with patch.object(self.screen, "submit_request") as submit_request:
            self.screen._footer_button.click()
        submit_request.assert_called_once_with()

        self.screen._name_input.setText("Unsaved Customer")
        self.screen._cancel_button.click()
        self.assertEqual(self.screen._step_stack.currentIndex(), 0)
        self.assertIsNone(self.screen._selected_service())
        self.assertEqual(self.screen._name_input.text(), "")
        self.assertEqual(self.database.get_appointments(), [])


if __name__ == "__main__":
    unittest.main()
