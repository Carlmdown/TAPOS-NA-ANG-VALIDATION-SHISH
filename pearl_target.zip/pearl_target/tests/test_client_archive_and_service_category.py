from database import Database
from models import Customer, Service


def test_client_with_foreign_key_history_is_archived(tmp_path):
    database = Database(tmp_path / "archive.sqlite")
    database.initialize_schema()
    database.add_client(Customer("Eunice Teodoro", "eunice@example.com"))
    service = database.add_service(Service("Test Manicure", 250))
    with database._connection:
        database._connection.execute(
            """INSERT INTO appointments
               (client_email, service_id, appointment_time, status)
               VALUES (?, ?, ?, ?)""",
            ("eunice@example.com", service.service_id,
             "2026-11-14T10:00:00", "PENDING"),
        )

    assert database.delete_client("eunice@example.com") is False
    assert database.get_clients() == []
    assert database._connection.execute(
        "SELECT archived FROM clients WHERE email = ?",
        ("eunice@example.com",),
    ).fetchone()[0] == 1
    assert database._connection.execute(
        "SELECT COUNT(*) FROM appointments WHERE client_email = ?",
        ("eunice@example.com",),
    ).fetchone()[0] == 1
    database.close()


def test_service_category_is_saved_and_loaded(tmp_path):
    database = Database(tmp_path / "category.sqlite")
    database.initialize_schema()
    service = database.add_service(
        Service("Structured Nails", 380, category="Manicure")
    )
    assert service.category == "Manicure"
    loaded = database.get_service(service.service_id)
    assert loaded is not None
    assert loaded.category == "Manicure"
    database.close()
