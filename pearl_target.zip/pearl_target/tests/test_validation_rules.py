import pytest

from models import Customer
from models._validation import validate_email, validate_person_name


def test_email_is_normalized_and_validated():
    assert validate_email("  Eunice@example.com  ") == "eunice@example.com"
    for value in ("", "plain-text", "name@", "name@example", "a..b@example.com", "name @example.com"):
        with pytest.raises(ValueError):
            validate_email(value)


def test_person_name_accepts_common_names_and_rejects_invalid_characters():
    assert validate_person_name("Eunice D. Teodoro") == "Eunice D. Teodoro"
    assert validate_person_name("Anne-Marie O’Neil") == "Anne-Marie O’Neil"
    assert validate_person_name("Mae-Lyn O’Connor") == "Mae-Lyn O’Connor"
    assert validate_person_name("Schmidt") == "Schmidt"
    for value in ("", "12345", "Name123", "<script>", "x" * 101, "asg argdsfvd", "akshdud", "1k2g33y2t13", "213123"):
        with pytest.raises(ValueError):
            validate_person_name(value)


def test_customer_model_rejects_invalid_email_and_name():
    with pytest.raises(ValueError):
        Customer("Eunice", "not-an-email")
    with pytest.raises(ValueError):
        Customer("Eunice123", "eunice@example.com")


def test_appointment_payment_method_accepts_only_configured_methods():
    from models.appointment import Appointment

    assert Appointment._validate_payment_method("Cash") == "Cash"
    assert Appointment._validate_payment_method("GCash / QR") == "GCash / QR"
    assert Appointment._validate_payment_method("Bank Transfer") == "Bank Transfer"
    for value in ("QR", "", "Bitcoin", None):
        if value == "":
            # Empty remains valid for unpaid legacy appointments.
            assert Appointment._validate_payment_method(value) == ""
        else:
            with pytest.raises(ValueError):
                Appointment._validate_payment_method(value)


def test_studio_owner_provider_name_uses_person_name_validation():
    from models.studio_settings import StudioSettings

    args = (0, 30, "Laguna home service")
    with pytest.raises(ValueError):
        StudioSettings(*args, owner_provider_name="akshdud")
    settings = StudioSettings(*args, owner_provider_name="Pearl Mae-Lyn")
    assert settings.owner_provider_name == "Pearl Mae-Lyn"


def test_account_display_names_reject_gibberish_and_accept_realistic_names():
    from models._validation import validate_person_name

    for invalid in ("askdhsuhdasi", "asjeh324324", "213123"):
        with pytest.raises(ValueError):
            validate_person_name(invalid, "Display name")

    for valid in ("Pearl", "Anne-Marie O’Neil", "Mae-Lyn O'Connor", "Ng"):
        assert validate_person_name(valid, "Display name") == valid
