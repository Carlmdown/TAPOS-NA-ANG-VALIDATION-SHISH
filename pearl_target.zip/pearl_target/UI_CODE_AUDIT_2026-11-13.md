# Pearl's SigNAILture — UI and Code Audit

Audited source archive: `Pearls_SigNAILture_Client_Service_Calendar_Fixes(1).zip`

## Applied in this audit

1. **Service base price field**
   - Replaced the service form's `QDoubleSpinBox` with a left-aligned editable `QLineEdit`.
   - Added a `QDoubleValidator` using a consistent dot decimal separator, with up to two decimal places and a maximum of PHP 1,000,000,000.
   - Preserved the behavior of pre-filling a new service with an existing service's price when available.
   - Added submit-time validation so blank, negative, malformed, and over-precision amounts cannot be saved.
   - The field has a clear placeholder and a 42px minimum height to improve visibility and typing comfort.
2. **Customer appointment calendar**
   - Reduced the calendar's fixed height from 270px to 250px and adjusted week-row sizing so the month/year navigation, weekday headings, and calendar rows have room inside the existing 306px card.
   - Kept the calendar and time-slot cards at the same outer height.
3. **Validation tests**
   - Added tests for whole-number and decimal prices, and rejection of blank, alphabetic, negative, comma-formatted, and more-than-two-decimal inputs.

## Static layout audit findings (not all changed automatically)

- There are 69 fixed/minimum/maximum geometry calls across UI modules. Some are appropriate (icons, thumbnails, compact controls); others can constrain layouts at different Windows scaling settings.
- `ServicePricingScreen` uses a 720px minimum service table plus a 320px minimum preview panel. Together with margins, this can squeeze the screen on narrower displays. Consider replacing hard minimum widths with a responsive splitter range and smaller breakpoints after visual testing.
- The customer gallery photo view has a 500x420 minimum image size, which can force scrolling or overflow on smaller windows.
- `QueuePanel` and appointment dialogs use 420px/460px minimum widths; verify these against the smallest supported display.
- Several admin/staff screens have fixed row/button/icon sizes. Keep these where they aid consistency, but verify at 100%, 125%, and 150% Windows display scaling.
- `ScrollableDialog` caps dialogs to the available screen and provides a scroll area, which is a good safeguard; individual content layouts still need visual checks for clipping.

## Preserved

- Original `styles/salon.qss` was not modified; original colors and theme remain intact.
- No database schema or existing customer/appointment/payment records were changed by this audit.
- Existing service category, duration, length-price, design add-on, and service-image workflows remain in place.

## Verification limits

- Python compilation completed successfully.
- Targeted pure-Python validation and database tests passed (8 tests).
- Full GUI test collection could not run in this environment because PyQt6 is not installed. Actual text cursor rendering, Windows display scaling, and calendar appearance must be confirmed on the user's computer.
