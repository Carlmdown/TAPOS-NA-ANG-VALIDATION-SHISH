# Pearl's SigNAILture – targeted fixes (13 November 2026)

## Loyalty card
- Reorganized the customer-facing loyalty instructions into separate How to Earn Stamps, Rewards, and Terms & Conditions sections.
- Uses the configured minimum spend and stamp count.
- Excludes travel fees from the qualifying service spend.
- Rewards are explicit: 5 stamps = 1 prize draw entry; 10 stamps = 1 additional entry.
- Default terms are concise and no longer repeat the earning/reward rules.
- Existing databases containing either previous default terms are migrated; custom terms are preserved.

## Service pricing
- Kept the service Price column explicitly visible in all category filters.
- Kept the service price editor numeric/editable and aligned its currency input to the left.
- Existing service price is still used as the starting value for a new service when available.

## Queue validation and cancellation
- QueueManager now validates client names at the business-logic boundary, not only in the UI. Obvious gibberish, digits, and invalid characters are rejected before an entry is saved.
- Cancelling a booked appointment from the queue now also cancels its linked appointment, applying the existing cancellation policy. The queue confirmation explains this before proceeding.
- A cancelled booked queue entry is not silently re-added on the next refresh.
- A completed appointment cannot be cancelled from the queue, preserving its payment and loyalty history.
- A walk-in with a recorded payment cannot be cancelled as if no payment existed.

## Verification
- `tests/test_validation_rules.py`: 5 passed.
- `tests/test_queue_validation_and_cancellation.py`: 6 passed.
- `compileall`: passed.
- GUI tests could not be executed in this environment because PyQt6 is not installed. Run the application on the target Windows machine to verify the visual layout and interactive dialogs.
