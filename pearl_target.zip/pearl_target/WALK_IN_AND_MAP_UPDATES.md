# Walk-in payment and Laguna map updates

## Walk-in checkout

1. Add a walk-in and choose an existing or new customer.
2. Choose a configured salon service and confirm/edit the final service price.
3. The chosen service and quoted price are saved in SQLite with the queue entry, so they remain available after closing and reopening the app.
4. When staff marks the serving walk-in as done, the app asks staff to confirm the payment method: Cash, GCash / QR, or Bank Transfer.
5. The app records one full payment for the confirmed final price. Duplicate payments and unsupported payment methods are rejected.
6. Walk-in sales appear in Reports & Payments, the revenue summary, service transaction totals, and the Walk-in visit-type row.

Staff must verify that cash or the electronic transfer was actually received before confirming. The app records the staff confirmation; it does not connect to or independently verify GCash or bank transactions.

The walk-in price starts at the selected service's configured base price. Staff can adjust the final price in the walk-in dialog to account for the actual agreed service total. This checkout does not automatically calculate appointment-only add-ons, discounts, or travel fees.

## Laguna map persistence

- With no custom Google Maps embed URL configured, the map defaults to a province-wide Laguna view with the salon marker at 14.2568824, 121.3663611.
- Map embed URL, map coordinates, map link, and map picture path are stored in the SQLite `studio_settings` record.
- A selected map picture is copied into `assets/map/` and its relative project path is stored in SQLite, so moving the project folder together preserves it.
- Click **Save** in Studio Settings after changing map details. Keep the `assets/map/` folder and the `data/pearls_signature.sqlite` database when backing up or moving the project.
- A custom Google Maps embed URL takes precedence over the default Laguna-wide map view.

## Google Maps embed rendering fix

- The Map page now wraps the saved Google Maps embed URL in a full-size HTML iframe before loading it in PyQt6-WebEngine.
- This avoids opening the Embed URL as a top-level page, which triggers Google's "The Google Maps Embed API must be used in an iframe" message.
- OpenStreetMap fallback URLs continue to load directly.
