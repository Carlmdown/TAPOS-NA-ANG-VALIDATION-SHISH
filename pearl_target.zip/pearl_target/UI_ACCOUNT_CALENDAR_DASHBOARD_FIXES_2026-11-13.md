# UI and account validation improvements – 2026-11-13

- Account creation, first-admin setup, and account profile updates now validate display names with the shared person-name validator.
- The service base-price input has an explicit readable foreground/background, a wider editing area, and retains its editable peso-prefixed numeric control.
- The appointment calendar has a wider/minimum-height layout and visible date grid.
- Appointment action buttons are grouped in a consistent four-column grid with matching heights and spacing; existing button colors and handlers are retained.
- The Admin dashboard now includes a six-month revenue bar chart populated from ReportManager's real monthly revenue queries. It is shown only to roles with report permission.

Validation notes:
- The name heuristic rejects obvious keyboard mash and numeric strings, but no algorithm can establish a person's legal identity. Unusual or very short names may require manual review.
- GUI appearance should still be checked on the target Windows/PyQt6 installation because PyQt6 is not installed in this build environment.
