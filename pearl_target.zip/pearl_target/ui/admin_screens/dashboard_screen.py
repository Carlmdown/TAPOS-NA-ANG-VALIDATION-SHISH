import sqlite3
from datetime import date, datetime

from PyQt6.QtCore import QRectF, Qt
from PyQt6.QtGui import QColor, QFont, QPainter, QPen
from PyQt6.QtWidgets import (
    QFrame,
    QGridLayout,
    QSizePolicy,
    QWidget,
    QLabel,
    QMessageBox,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from models import User
from services.report_manager import ReportManager
from ui.appointment_panel import AppointmentPanel
from ui.base_page import BasePage


class RevenueBarChart(QWidget):
    """Small native Qt bar chart; values are supplied by real report queries."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._values: list[tuple[str, float]] = []
        self.setMinimumHeight(210)
        self.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed
        )

    def set_values(self, values: list[tuple[str, float]]) -> None:
        self._values = values
        self.update()

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), QColor("#FFFFFF"))
        painter.setPen(QPen(QColor("#E3E9EE"), 1))
        left, right, top, bottom = 58, 18, 18, 42
        chart = QRectF(
            left, top, max(1, self.width() - left - right),
            max(1, self.height() - top - bottom)
        )
        painter.drawLine(int(chart.left()), int(chart.bottom()),
                         int(chart.right()), int(chart.bottom()))
        maximum = max((max(0.0, value) for _, value in self._values), default=0.0)
        maximum = maximum or 1.0
        painter.setFont(QFont("Segoe UI", 8))
        painter.setPen(QColor("#71808D"))
        for tick in range(5):
            value = maximum * (4 - tick) / 4
            y = chart.top() + chart.height() * tick / 4
            painter.setPen(QPen(QColor("#EEF1F4"), 1))
            painter.drawLine(int(chart.left()), int(y), int(chart.right()), int(y))
            painter.setPen(QColor("#71808D"))
            painter.drawText(4, int(y + 4), f"₱{value:,.0f}")
        if not self._values:
            painter.drawText(chart, Qt.AlignmentFlag.AlignCenter,
                             "No revenue data available yet")
            return
        slot = chart.width() / len(self._values)
        bar_width = min(42.0, slot * 0.56)
        for index, (label, amount) in enumerate(self._values):
            amount = max(0.0, float(amount))
            bar_height = chart.height() * amount / maximum
            x = chart.left() + index * slot + (slot - bar_width) / 2
            y = chart.bottom() - bar_height
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor("#7896A4"))
            painter.drawRoundedRect(QRectF(x, y, bar_width, bar_height), 5, 5)
            painter.setPen(QColor("#657583"))
            painter.drawText(
                QRectF(chart.left() + index * slot, chart.bottom() + 7,
                       slot, 24),
                Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop,
                label,
            )


class DashboardScreen(BasePage):
    """Role-aware appointment dashboard built from read-only reports."""

    def __init__(
        self,
        report_manager: ReportManager,
        appointment_panel: AppointmentPanel,
        role: User,
        parent=None,
    ) -> None:
        if "view_dashboard" not in role.get_permissions():
            raise PermissionError("This role cannot view the dashboard")
        # Inheritance and dependency injection: BasePage uses report and appointment services.
        self._report_manager = report_manager
        self._appointment_panel = appointment_panel
        self._role = role
        super().__init__(
            {
                "report_manager": report_manager,
                "appointment_panel": appointment_panel,
            },
            parent,
        )
        self.refresh()

    @property
    def report_manager(self) -> ReportManager:
        return self._report_manager

    @property
    def appointment_panel(self) -> AppointmentPanel:
        return self._appointment_panel

    def build_ui(self) -> None:
        layout = QVBoxLayout(self)
        title = QLabel(self._role.get_dashboard_title())
        title.setObjectName("appTitle")
        layout.addWidget(title)

        self._cards_layout = QGridLayout()
        layout.addLayout(self._cards_layout)
        self._card_values: dict[str, QLabel] = {}
        card_specs = [
            ("today", "Today's appointments"),
            ("pending", "Pending requests"),
            ("upcoming", "Upcoming (7 days)"),
        ]
        permissions = self._role.get_permissions()
        if "view_payments" in permissions:
            card_specs.append(("payments", "Pending payments"))
        if "view_reports" in permissions:
            card_specs.append(("revenue", "Revenue this month"))
        for index, (key, label) in enumerate(card_specs):
            card = QFrame()
            card.setProperty("card", True)
            card_layout = QVBoxLayout(card)
            label_widget = QLabel(label)
            label_widget.setWordWrap(True)
            value = QLabel("—")
            value.setStyleSheet(
                "font-size: 20px; font-weight: 700; color: #765f43;"
            )
            card_layout.addWidget(label_widget)
            card_layout.addWidget(value)
            self._cards_layout.addWidget(card, index // 3, index % 3)
            self._card_values[key] = value

        self._revenue_chart = None
        if "view_reports" in permissions:
            chart_heading = QLabel("Revenue – last 6 months")
            chart_heading.setStyleSheet(
                "font-size: 15px; font-weight: 700; color: #344252;"
            )
            self._revenue_chart = RevenueBarChart()
            layout.addWidget(chart_heading)
            layout.addWidget(self._revenue_chart)

        self._today_table = self._create_table()
        self._upcoming_table = self._create_table()
        layout.addWidget(QLabel("Today's appointments"))
        layout.addWidget(self._today_table, 1)
        layout.addWidget(QLabel("Next 7 days"))
        layout.addWidget(self._upcoming_table, 1)
        self._today_table.cellDoubleClicked.connect(
            lambda row, _column: self._open_details(self._today_table, row)
        )
        self._upcoming_table.cellDoubleClicked.connect(
            lambda row, _column: self._open_details(self._upcoming_table, row)
        )

    @staticmethod
    def _create_table() -> QTableWidget:
        table = QTableWidget(0, 5)
        table.setHorizontalHeaderLabels(
            ["Time", "Client", "Service", "Visit type", "Status"]
        )
        table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        table.setWordWrap(True)
        header = table.horizontalHeader()
        if header is not None:
            header.setStretchLastSection(True)
        return table

    def refresh(self) -> None:
        try:
            today_rows = self._report_manager.today_appointments(self._role)
            upcoming_rows = self._report_manager.upcoming_appointments(self._role, 7)
            self._card_values["today"].setText(str(len(today_rows)))
            self._card_values["pending"].setText(
                str(self._report_manager.pending_request_count())
            )
            self._card_values["upcoming"].setText(str(len(upcoming_rows)))
            if "view_payments" in self._role.get_permissions():
                payments = self._report_manager.pending_payments(self._role)
                self._card_values["payments"].setText(
                    f"₱ {payments['total_balance']:,.2f}"
                )
            if "view_reports" in self._role.get_permissions():
                today = datetime.now().date()
                first_day = today.replace(day=1)
                self._card_values["revenue"].setText(
                    f"₱ {self._report_manager.revenue(first_day, today, self._role):,.2f}"
                )
                if self._revenue_chart is not None:
                    chart_values = []
                    year, month = today.year, today.month
                    month_starts = []
                    for _ in range(6):
                        month_starts.append(date(year, month, 1))
                        month -= 1
                        if month == 0:
                            month, year = 12, year - 1
                    month_starts.reverse()
                    for month_start in month_starts:
                        if month_start.month == 12:
                            next_month = date(month_start.year + 1, 1, 1)
                        else:
                            next_month = date(month_start.year, month_start.month + 1, 1)
                        month_end = min(today, date.fromordinal(next_month.toordinal() - 1))
                        amount = self._report_manager.revenue(
                            month_start, month_end, self._role
                        ) if month_start <= today else 0.0
                        chart_values.append((month_start.strftime("%b"), amount))
                    self._revenue_chart.set_values(chart_values)
            self._populate_table(self._today_table, today_rows, show_date=False)
            self._populate_table(self._upcoming_table, upcoming_rows, show_date=True)
        except (sqlite3.Error, TypeError, ValueError, KeyError) as error:
            QMessageBox.critical(self, "Could not load dashboard", str(error))

    @staticmethod
    def _populate_table(
        table: QTableWidget, rows: list[dict[str, object]], show_date: bool
    ) -> None:
        table.setRowCount(0)
        for record in rows:
            row = table.rowCount()
            table.insertRow(row)
            appointment_time = datetime.fromisoformat(str(record["appointment_time"]))
            time_text = (
                f"{appointment_time:%a %d %b %H:%M}"
                if show_date
                else f"{appointment_time:%H:%M}"
            )
            values = (
                time_text,
                str(record["client_name"]),
                str(record["service_name"]),
                str(record["visit_type"]).replace("_", " ").title(),
                str(record["status"]).replace("_", " ").title(),
            )
            for column, value in enumerate(values):
                item = QTableWidgetItem(value)
                if column == 0:
                    item.setData(
                        Qt.ItemDataRole.UserRole, record["appointment_id"]
                    )
                table.setItem(row, column, item)

    def _open_details(self, table: QTableWidget, row: int) -> None:
        item = table.item(row, 0)
        if item is None:
            return
        appointment_id = item.data(Qt.ItemDataRole.UserRole)
        if isinstance(appointment_id, int):
            self._appointment_panel.show_appointment_details(appointment_id)
